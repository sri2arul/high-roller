extends Button

func _pressed():
	print("main menu - coming soon")
